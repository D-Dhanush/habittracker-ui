export interface HabitTaskDto {
  id: string;
  name: string;
  description?: string;
  completed: boolean;
  completedDate?: string;
  xpReward?: number;
}

export interface HabitCompletionDto {
  date: string;
  completed: boolean;
  xpEarned: number;
  notes?: string;
}

export interface HabitMilestoneDto {
  id: string;
  name: string;
  description: string;
  target: number;
  achieved: boolean;
  achievedDate?: string;
  xpReward: number;
  icon: string;
}

export interface HabitDto {
  id: string;
  name: string;
  subtitle?: string;
  description?: string;

  category?: string;
  customCategory?: string;

  frequency: string;
  status?: string;

  icon?: string;
  primaryIcon?: string;
  secondaryIcon?: string;
  customName?: string;

  primaryColor?: string;
  secondaryColor?: string;

  xpReward?: number;

  startDt?: string;
  endDt?: string;

  targetOccurrencesPerPeriod?: number;
  reminderTimeUtc?: string;

  recentCompletions?: HabitCompletionDto[];
  tasks?: HabitTaskDto[];
  milestones?: HabitMilestoneDto[];

  tagsList?: string[];

  notes?: string;

  createdDt?: string;
  updatedDt?: string;

  type?: string;
  isActive?: boolean;
}